# Autograntor: starter package

The Autograntor scores a grant in utility units, where a Plan A-style US–China pause treaty = 1,000,000. It runs as a Claude skill with five steps:

1. A structural pre-pass that fixes the facts and the no-grant world.
2. Two independent estimators that build ledgers.
3. A critique round, run only if the estimators disagree.
4. A neutral judge who produces the final verdict.
5. Upkeep, where new Proposed rulings and milestones are recorded.

Packaged 2026-11-12 (PERCYs v4).

## What's in here

```
skill/grant-adversarial-estimate-v2/SKILL.md   the skill itself (the coordinator's instructions)
claude/                                        the "standard documents" every agent reads
  common_law_core.md                           Part I + Adopted rulings (always read)
  common_law_index.md                          one line per ruling CL-1..83
  common_law_topics/*.md                       Proposed rulings CL-14..83, by topic
  common_law_proposed/*.md                     rulings added after the freeze (CL-84..94), one file per run
  milestones_weights.md                        Canonical milestone weights (the utility scale)
  milestones_added.md                          Approved and Proposed milestones and parameters
  PERCYs_v4.md                                 pricing rules for persuasion / media grants (v4, adopted 2026-11-12)
  simulate.py, ledger_template.csv             ledger simulator (Monte Carlo, diff, values branches)
  mean_range.py                                range-on-the-mean helper for the judge
  fetch_manifund.py                            reads a Manifund listing as data
```

## Setup

1. **Make a claude.ai Project** and add every file under `claude/` to it at the **same path**, e.g. `claude/common_law_core.md` or `claude/common_law_topics/money-and-funders.md`. The skill and its subagents read these by exact path with the Projects tool. The easiest way is to open a Claude session attached to the Project, upload this ZIP, and ask Claude to write each file to the Project at its `claude/...` path.
2. **Install the skill.** Upload the `skill/grant-adversarial-estimate-v2/` folder as a custom skill in claude.ai (zip that folder and upload it where claude.ai lets you add skills).
3. **Run it** from a session attached to that Project: "Run the autograntor (grant-adversarial-estimate-v2) on <link or attached application>".

## Requirements and optional pieces

- **Python 3 with numpy**, for `simulate.py`. The skill copies the scripts into its working folder at the start of each run.
- **Subagents.** The skill launches several Claude subagents. They need the Projects tool, which is why the skill insists on launching them in the foreground.
- **Optional: FutureSearch MCP connector.** Used for a few probabilistic forecasts. Without it, the pre-pass records "not resolved" and continues.
- **Not included: Lightcone Commons connector.** The skill can read applications from Lightcone Commons through a separate access skill. That needs a personal access token and is not part of this package. Without it, give the skill an attached application, a Manifund listing (it uses `fetch_manifund.py`) or another public application page.
- **Funder names.** The funder tiers in CL-91 and some instructions reflect the original user's policy, for example the funding platform's own money priced at 50 per $1M. Edit `common_law_core.md` if your situation differs.

## How the documents evolve

Each run writes the following to the Project:

- a report
- a brief
- ledgers
- at most three new Proposed rulings, as a new file in `claude/common_law_proposed/`
- new Proposed milestones, appended to `claude/milestones_added.md`

Only the human user adopts rulings or promotes milestones. See the README in `common_law_proposed/` and the headers of the milestone files.
